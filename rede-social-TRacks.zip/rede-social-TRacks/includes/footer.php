<?php
?>
    </main>
    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 TRacks - Da Rede ao Mundo</p>
        </div>
    </footer>
    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/feed.js"></script>
    <script src="../assets/js/chat.js"></script>
</body>
</html>